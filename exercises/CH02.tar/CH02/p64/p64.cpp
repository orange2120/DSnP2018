#include <iostream>
#include "a.h"
using namespace std;

int main()
{
    void *ptr;
    N n1(ptr), n2(ptr);
}