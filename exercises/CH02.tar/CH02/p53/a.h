#ifndef A_H
#define A_H

class A
{
};

#endif