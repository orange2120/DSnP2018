#include <iostream>
using namespace std;

void f(int a = 10);

int main()
{
    f(10);
}

void f(int a)
{
}