#include <iostream>
#include "a.h"
#include "b.h"

using namespace std;

int main()
{
    A a;
    B b;
}